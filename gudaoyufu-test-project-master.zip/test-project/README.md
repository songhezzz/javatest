#Spring Boot Demo
run DemoApplication

http://localhost:8080

#Docker Demo
copy tartget/*.jar to docker/

``
docker-compose up
``